//
//  main.m
//  AvoidCrash
//
//  Created by 启业云 on 2019/8/19.
//  Copyright © 2019 启业云. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
