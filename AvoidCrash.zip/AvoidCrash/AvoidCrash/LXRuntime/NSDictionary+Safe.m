//
//  NSDictionary+Safe.m
//  AvoidCrash
//
//  Created by 启业云 on 2019/8/29.
//  Copyright © 2019 启业云. All rights reserved.
//

#import "NSDictionary+Safe.h"

@implementation NSDictionary (Safe)

@end
