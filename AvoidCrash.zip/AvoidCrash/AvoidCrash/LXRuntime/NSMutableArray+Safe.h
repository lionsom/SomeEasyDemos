//
//  NSMutableArray+Safe.h
//  AvoidCrash
//
//  Created by 启业云 on 2019/8/29.
//  Copyright © 2019 启业云. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSMutableArray (Safe)

@end

NS_ASSUME_NONNULL_END
